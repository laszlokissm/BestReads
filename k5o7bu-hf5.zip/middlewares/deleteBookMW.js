/**
 * Delete a book from the database
 * @param {object} objRepo
 */
module.exports = (objRepo) => {
    return (res, req, next) => {
        next();
    }
}