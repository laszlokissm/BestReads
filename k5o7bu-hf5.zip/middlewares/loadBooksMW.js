/**
 * Load all books from the database
 * @param {object} objRepo
 * @returns {function(*, *, *): *} 
 */
module.exports = (objRepo) => {
    return (res, req, next) => {
        next();
    }
}