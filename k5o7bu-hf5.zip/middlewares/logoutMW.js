/**
 * Logout middleware
 * @param objRepo
 */
module.exports = (objRepo) => {
    return (res, req, next) => {
        next();
    }
}