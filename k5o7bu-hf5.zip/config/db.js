const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/k5o7bu');

module.exports = mongoose;